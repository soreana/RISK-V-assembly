#include <stdio.h>
#include <stdlib.h>

extern void my_assembly_function(void);

int main(void) {
  
  my_assembly_function();

}
